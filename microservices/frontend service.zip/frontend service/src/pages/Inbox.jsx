function Inbox() {
    return (
      <div>
        <h2>Inbox Page</h2>
      </div>
    );
  }
  
  export default Inbox;
  